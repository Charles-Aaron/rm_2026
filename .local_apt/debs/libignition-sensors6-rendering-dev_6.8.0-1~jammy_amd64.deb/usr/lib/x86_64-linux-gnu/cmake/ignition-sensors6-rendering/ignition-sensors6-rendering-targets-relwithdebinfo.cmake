#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ignition-sensors6::ignition-sensors6-rendering" for configuration "RelWithDebInfo"
set_property(TARGET ignition-sensors6::ignition-sensors6-rendering APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ignition-sensors6::ignition-sensors6-rendering PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libignition-sensors6-rendering.so.6.8.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libignition-sensors6-rendering.so.6"
  )

list(APPEND _IMPORT_CHECK_TARGETS ignition-sensors6::ignition-sensors6-rendering )
list(APPEND _IMPORT_CHECK_FILES_FOR_ignition-sensors6::ignition-sensors6-rendering "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libignition-sensors6-rendering.so.6.8.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
