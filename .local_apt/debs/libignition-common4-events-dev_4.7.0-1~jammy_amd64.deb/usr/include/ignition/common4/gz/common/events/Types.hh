/*
 * Copyright (C) 2018 Open Source Robotics Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
*/

#ifndef GZ_COMMON_EVENTS_TYPES_HH_
#define GZ_COMMON_EVENTS_TYPES_HH_

#include <memory>

#include <gz/common/config.hh>

// This header contains forward declarations for some event types
namespace ignition
{
  namespace common
  {
    class Connection;

    /// \def ConnectionPtr
    /// \brief Shared pointer to a Connection object
    using ConnectionPtr = std::shared_ptr<Connection>;
  }
}

#endif
