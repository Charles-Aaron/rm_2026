#!/usr/bin/ruby

# Copyright (C) 2020 Open Source Robotics Foundation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# We use 'dl' for Ruby <= 1.9.x and 'fiddle' for Ruby >= 2.0.x
if RUBY_VERSION.split('.')[0] < '2'
  require 'dl'
  require 'dl/import'
  include DL
else
  require 'fiddle'
  require 'fiddle/import'
  include Fiddle
end

require 'optparse'

# Constants.
LIBRARY_NAME = '../../../lib/x86_64-linux-gnu/libignition-plugin1-loader.so.1.4.0'
LIBRARY_VERSION = '1.4.0'
COMMON_OPTIONS =
               "  -h [ --help ]              Print this help message.\n"\
               "                                                    \n"        +
               "  --force-version <VERSION>  Use a specific library version.\n"\
               "                                                    \n"        +
               '  --versions                 Show the available versions.'
COMMANDS = {  'plugin' =>
                    "Print information about plugins.\n\n"                    +
                    "  ign plugin [options]\n\n"                              +
                    "Options:\n\n"                                            +
                    "  -i [ --info ]              Get info about a plugin.\n" +
                    "                             Requires the -p option.\n"  +
                    "\n"                                                      +
                    "  -p [ --plugin ] arg        Path to a plugin.\n"        +
                    "                             Required with -i.\n"        +
                    "\n"                                                      +
                    "  -v [ --verbose ]           Print verbose info.\n"      +
                    "\n"                                                      +
                    COMMON_OPTIONS
           }

#
# Class for the Ignition plugin command line tools.
#
class Cmd
  #
  # Return a structure describing the options.
  #
  def parse(args)
    options = {}

    usage = COMMANDS[args[0]]

    # Read the command line arguments.
    opt_parser = OptionParser.new do |opts|
      opts.banner = usage

      opts.on('-h', '--help', 'Print this help message') do
        puts usage
        exit(0)
      end

      opts.on('-i', '--info', String,
              'Print information about a plugin') do |t|
        options['info'] = t
      end

      opts.on('-p plugin', '--plugin', String,
              'Plugin name') do |t|
        options['plugin'] = t
      end

      opts.on('-v', '--verbose', 'Print verbose info') do
        options["verbose"] = 1
      end

    end
    begin
      opt_parser.parse!(args)
    rescue
      puts usage
      exit(-1)
    end

    # Check that there is at least one command and there is a plugin that knows
    # how to handle it.
    if ARGV.empty? || !COMMANDS.key?(ARGV[0]) ||
       options.empty?
      puts usage
      exit(-1)
    end

    options['command'] = ARGV[0]

    options
  end  # parse()

  def execute(args)
    options = parse(args)

    # puts 'Parsed:'
    # puts options

    # Read the plugin that handles the command.
    if LIBRARY_NAME[0] == '/'
      # If the first character is a slash, we'll assume that we've been given an
      # absolute path to the library. This is only used during test mode.
      plugin = LIBRARY_NAME
    else
      # We're assuming that the library path is relative to the current
      # location of this script.
      plugin = File.expand_path(File.join(File.dirname(__FILE__), LIBRARY_NAME))
    end
    conf_version = LIBRARY_VERSION

    begin
      Importer.dlload plugin
    rescue DLError
      puts "Library error: [#{plugin}] not found."
      if plugin.end_with? ".dylib"
        puts "If this script was executed with /usr/bin/ruby, this error may be caused by
macOS System Integrity Protection. One workaround is to use a different
version of ruby, for example:
    brew install ruby
and add the following line to your shell profile:
    export PATH=/usr/local/opt/ruby/bin:$PATH"
      end
      exit(-1)
    end

    # Read the library version.
    Importer.extern 'char* ignitionVersion()'
    begin
      plugin_version = Importer.ignitionVersion.to_s
    rescue DLError
      puts "Library error: Problem running 'ignitionVersion()' from #{plugin}."
      exit(-1)
    end

    # Sanity check: Verify that the version of the yaml file matches the version
    # of the library that we are using.
    unless plugin_version.eql? conf_version
      puts "Error: Version mismatch. Your configuration file version is
            [#{conf_version}] but #{plugin} version is [#{plugin_version}]."
      exit(-1)
    end

    begin
      case options['command']
      when 'plugin'
        if options.key?('info')
          if not options.key?('plugin')
            puts 'ign plugin --info: missing plugin name (-p <plugin>)'
            puts 'Try ign plugin --help'
          else
            options["verbose"] = 0 if !options.key?('verbose')
            Importer.extern 'void cmdPluginInfo(const char *, int)'
            Importer.cmdPluginInfo(options['plugin'], options["verbose"])
          end
        else
          puts 'Command error: I do not have an implementation '\
               'for this command.'
        end
      else
        puts 'Command error: I do not have an implementation for '\
             "command [ign #{options['command']}]."
      end
    rescue
      puts "Library error: Problem running [#{options['command']}]() "\
           "from #{plugin}."
    end
  end
end
